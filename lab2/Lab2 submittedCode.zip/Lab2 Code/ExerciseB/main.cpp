// ENSF 480 - Lab 2 - Exercise B
// Completed by: Mirza Hassan Baig
// Submission Date: Oct 1, 2023
// File Name: main.cpp

#include "GraphicsWorld.h"

int main()
{
    GraphicsWorld gw;
    gw.run();
    return 0;
}
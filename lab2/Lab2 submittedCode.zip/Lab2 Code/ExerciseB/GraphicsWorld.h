// ENSF 480 - Lab 2 - Exercise B
// Completed by: Mirza Hassan Baig
// Submission Date: Oct 1, 2023
// File Name: GraphicsWorld.h

#ifndef GRAPHICSWORLD_H
#define GRAPHICSWORLD_H

class GraphicsWorld
{
public:
    void run();
};

#endif